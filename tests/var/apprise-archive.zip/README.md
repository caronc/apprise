This file was found on https://github.com/caronc/apprise and is only used
as a temporary file to exist within a compressed file for unit testing.
